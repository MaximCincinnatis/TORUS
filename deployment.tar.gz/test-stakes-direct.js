const { ethers } = require('ethers');

const RPC_URL = 'https://ethereum-rpc.publicnode.com';
const CONTRACT_ADDRESS = '0xc7cc775b21f9df85e043c7fdd9dac60af0b69507';

async function testStakeEventsDirect() {
  console.log('Testing Staked events with direct topic search...\n');
  
  const provider = new ethers.JsonRpcProvider(RPC_URL);
  
  // Calculate the event topic for Staked(address,uint256,uint256,uint256,uint256)
  const eventSignature = "Staked(address,uint256,uint256,uint256,uint256)";
  const eventTopic = ethers.id(eventSignature);
  console.log(`Event signature: ${eventSignature}`);
  console.log(`Event topic: ${eventTopic}`);
  
  const currentBlock = await provider.getBlockNumber();
  const fromBlock = currentBlock - 45000;
  
  console.log(`\nSearching blocks ${fromBlock} to ${currentBlock}...`);
  
  try {
    // Direct log search
    const logs = await provider.getLogs({
      address: CONTRACT_ADDRESS,
      topics: [eventTopic],
      fromBlock: fromBlock,
      toBlock: currentBlock
    });
    
    console.log(`\nFound ${logs.length} logs with Staked event topic`);
    
    // Also check what events ARE present
    console.log('\nChecking all events from contract in last 1000 blocks...');
    const recentLogs = await provider.getLogs({
      address: CONTRACT_ADDRESS,
      fromBlock: currentBlock - 1000,
      toBlock: currentBlock
    });
    
    // Group by event topic
    const eventCounts = {};
    recentLogs.forEach(log => {
      const topic = log.topics[0];
      eventCounts[topic] = (eventCounts[topic] || 0) + 1;
    });
    
    console.log('\nEvent topics found:');
    Object.entries(eventCounts).forEach(([topic, count]) => {
      console.log(`  ${topic}: ${count} events`);
    });
    
    // Decode known topics
    const knownTopics = {
      [ethers.id("Created(address,uint256,uint256,uint256)")]: "Created",
      [ethers.id("Staked(address,uint256,uint256,uint256,uint256,uint256)")]: "Staked",
      [ethers.id("Claimed(address,uint256,uint256,uint256,uint256)")]: "Claimed",
      [ethers.id("Transfer(address,address,uint256)")]: "Transfer",
      [ethers.id("Approval(address,address,uint256)")]: "Approval"
    };
    
    console.log('\nDecoded event types:');
    Object.entries(eventCounts).forEach(([topic, count]) => {
      const eventName = knownTopics[topic] || 'Unknown';
      console.log(`  ${eventName}: ${count} events`);
    });
    
  } catch (error) {
    console.error('Error:', error.message);
  }
}

testStakeEventsDirect();
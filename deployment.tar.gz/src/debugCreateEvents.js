const { ethers } = require('ethers');

const TORUS_CREATE_STAKE = '0xc7cc775b21f9df85e043c7fdd9dac60af0b69507';
const CREATE_EVENT_ABI = [{
  "anonymous": false,
  "inputs": [
    {"indexed": true, "internalType": "address", "name": "user", "type": "address"},
    {"indexed": false, "internalType": "uint256", "name": "stakeIndex", "type": "uint256"},
    {"indexed": false, "internalType": "uint256", "name": "torusAmount", "type": "uint256"},
    {"indexed": false, "internalType": "uint256", "name": "endTime", "type": "uint256"}
  ],
  "name": "Created",
  "type": "event"
}];

async function debugCreateEvents() {
  console.log('🔍 DEBUGGING CREATE EVENTS FETCH\n');
  
  const provider = new ethers.JsonRpcProvider('https://ethereum.publicnode.com');
  const contract = new ethers.Contract(TORUS_CREATE_STAKE, CREATE_EVENT_ABI, provider);
  
  const currentBlock = await provider.getBlockNumber();
  const deploymentBlock = 22890272;
  
  console.log('Contract Details:');
  console.log('  Address:', TORUS_CREATE_STAKE);
  console.log('  Deployment Block:', deploymentBlock);
  console.log('  Current Block:', currentBlock);
  console.log('  Blocks Since Deploy:', currentBlock - deploymentBlock);
  
  // Test small chunks around deployment
  console.log('\n📊 Testing event fetching in chunks:\n');
  
  const testRanges = [
    { from: deploymentBlock, to: deploymentBlock + 1000, label: 'First 1000 blocks' },
    { from: deploymentBlock, to: deploymentBlock + 5000, label: 'First 5000 blocks' },
    { from: currentBlock - 10000, to: currentBlock, label: 'Last 10000 blocks' },
    { from: deploymentBlock, to: currentBlock, label: 'FULL RANGE (deployment to current)' },
  ];
  
  for (const range of testRanges) {
    try {
      console.log(`Testing ${range.label}...`);
      console.log(`  Blocks ${range.from} to ${range.to} (${range.to - range.from} blocks)`);
      
      const filter = contract.filters.Created();
      const startTime = Date.now();
      const events = await contract.queryFilter(filter, range.from, range.to);
      const elapsed = Date.now() - startTime;
      
      console.log(`  ✅ Found ${events.length} events in ${elapsed}ms`);
      
      if (events.length > 0) {
        console.log(`  First event: Block ${events[0].blockNumber}`);
        console.log(`  Last event: Block ${events[events.length - 1].blockNumber}`);
        
        // Show first event details
        const firstEvent = events[0];
        console.log(`  First event details:`);
        console.log(`    User: ${firstEvent.args.user}`);
        console.log(`    TORUS: ${ethers.formatEther(firstEvent.args.torusAmount)}`);
        console.log(`    Block: ${firstEvent.blockNumber}`);
      }
      console.log('');
    } catch (error) {
      console.log(`  ❌ ERROR: ${error.message}\n`);
    }
  }
  
  // Test the exact filter being used in the dashboard
  console.log('📋 Testing dashboard-style filter:\n');
  try {
    const filter = contract.filters.Created();
    console.log('Filter object:', JSON.stringify(filter, null, 2));
    
    // Try getting events in the same way the dashboard does
    const maxBlockRange = 45000;
    const events = [];
    let fromBlock = deploymentBlock;
    
    while (fromBlock <= currentBlock) {
      const toBlock = Math.min(fromBlock + maxBlockRange, currentBlock);
      console.log(`Fetching chunk: ${fromBlock} to ${toBlock}...`);
      
      const chunkEvents = await contract.queryFilter(filter, fromBlock, toBlock);
      events.push(...chunkEvents);
      console.log(`  Found ${chunkEvents.length} events`);
      
      fromBlock = toBlock + 1;
      
      // Stop after first chunk with events for debugging
      if (chunkEvents.length > 0 && events.length > 10) {
        console.log('  (Stopping after finding some events for debugging)');
        break;
      }
    }
    
    console.log(`\nTotal events found: ${events.length}`);
  } catch (error) {
    console.log('ERROR in dashboard-style fetch:', error);
  }
}

debugCreateEvents().catch(console.error);
const { ethers } = require('ethers');

const provider = new ethers.JsonRpcProvider('https://eth.llamarpc.com');
const NFT_POSITION_MANAGER = '0xC36442b4a4522E871399CD717aBDD847Ab11FE88';

// The actual Uniswap V3 Position Manager has a collect function that calculates fees
const POSITION_MANAGER_ABI = [
  'function positions(uint256 tokenId) view returns (uint96 nonce, address operator, address token0, address token1, uint24 fee, int24 tickLower, int24 tickUpper, uint128 liquidity, uint256 feeGrowthInside0LastX128, uint256 feeGrowthInside1LastX128, uint128 tokensOwed0, uint128 tokensOwed1)',
  'function ownerOf(uint256 tokenId) view returns (address)',
  // This is the key - we can simulate calling collect to see what would be collected
  'function collect(tuple(uint256 tokenId, address recipient, uint128 amount0Max, uint128 amount1Max) params) returns (uint256 amount0, uint256 amount1)'
];

async function checkWithCollectSimulation(tokenId) {
  console.log(`\n=== Checking position ${tokenId} with collect simulation ===`);
  
  const positionManager = new ethers.Contract(NFT_POSITION_MANAGER, POSITION_MANAGER_ABI, provider);
  
  try {
    const position = await positionManager.positions(tokenId);
    const owner = await positionManager.ownerOf(tokenId);
    
    console.log(`Owner: ${owner}`);
    console.log(`Liquidity: ${position.liquidity.toString()}`);
    console.log(`Current tokensOwed0: ${position.tokensOwed0.toString()}`);
    console.log(`Current tokensOwed1: ${position.tokensOwed1.toString()}`);
    
    // The issue might be that the position needs to have its fees "burned in"
    // This happens when you call decreaseLiquidity(0) or collect
    
    // Let's check what the actual collectible amounts would be
    // by simulating a collect call
    const collectParams = {
      tokenId: tokenId,
      recipient: owner, // doesn't matter for simulation
      amount0Max: ethers.MaxUint128,
      amount1Max: ethers.MaxUint128
    };
    
    try {
      // Use staticCall to simulate without executing
      const result = await positionManager.collect.staticCall(collectParams, { from: owner });
      console.log('\nSimulated collect would return:');
      console.log(`  TORUS: ${Number(result.amount0) / 1e18}`);
      console.log(`  TitanX: ${Number(result.amount1) / 1e18} (${Number(result.amount1) / 1e18 / 1e6}M)`);
      
      if (Number(result.amount1) / 1e18 > 38000000 && Number(result.amount1) / 1e18 < 40000000) {
        console.log('\n🎯 FOUND IT! This position would collect ~39M TitanX!');
      }
    } catch (err) {
      console.log('\nCould not simulate collect:', err.reason || err.message);
    }
    
  } catch (error) {
    console.error('Error:', error);
  }
}

async function main() {
  // Check all three positions
  await checkWithCollectSimulation('1029236');
  await checkWithCollectSimulation('1030051');
  await checkWithCollectSimulation('1031465');
}

main().catch(console.error);
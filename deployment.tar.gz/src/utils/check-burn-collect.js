const { ethers } = require('ethers');

const provider = new ethers.JsonRpcProvider('https://eth.llamarpc.com');
const NFT_POSITION_MANAGER = '0xC36442b4a4522E871399CD717aBDD847Ab11FE88';
const POOL_ADDRESS = '0x7ff1f30F6E7EeC2ff3F0D1b60739115BDF88190F';

// Need the pool contract to check events
const POOL_ABI = [
  'event Burn(address indexed owner, int24 indexed tickLower, int24 indexed tickUpper, uint128 amount, uint256 amount0, uint256 amount1)',
  'event Collect(address indexed owner, address recipient, int24 indexed tickLower, int24 indexed tickUpper, uint128 amount0, uint128 amount1)'
];

const POSITION_MANAGER_ABI = [
  'function positions(uint256 tokenId) view returns (uint96 nonce, address operator, address token0, address token1, uint24 fee, int24 tickLower, int24 tickUpper, uint128 liquidity, uint256 feeGrowthInside0LastX128, uint256 feeGrowthInside1LastX128, uint128 tokensOwed0, uint128 tokensOwed1)',
  'event DecreaseLiquidity(uint256 indexed tokenId, uint128 liquidity, uint256 amount0, uint256 amount1)'
];

async function checkBurnAndCollect() {
  const pool = new ethers.Contract(POOL_ADDRESS, POOL_ABI, provider);
  const positionManager = new ethers.Contract(NFT_POSITION_MANAGER, POSITION_MANAGER_ABI, provider);
  
  console.log('Checking for burn/collect events in TORUS pool that might show 39M TitanX...\n');
  
  const currentBlock = await provider.getBlockNumber();
  
  // Look for recent burns with high TitanX amounts
  console.log('Searching for Burn events with ~39M TitanX...');
  
  // Check in smaller chunks
  for (let i = 0; i < 50; i++) {
    const fromBlock = currentBlock - (i + 1) * 1000;
    const toBlock = currentBlock - i * 1000;
    
    try {
      const burnFilter = pool.filters.Burn();
      const burns = await pool.queryFilter(burnFilter, fromBlock, toBlock);
      
      for (const burn of burns) {
        const titanX = Number(burn.args.amount1) / 1e18;
        const torus = Number(burn.args.amount0) / 1e18;
        
        if (titanX > 38000000 && titanX < 40000000 && torus > 0.7 && torus < 0.8) {
          console.log(`\n🎯 FOUND MATCHING BURN!`);
          console.log(`  Block: ${burn.blockNumber}`);
          console.log(`  Transaction: ${burn.transactionHash}`);
          console.log(`  Owner: ${burn.args.owner}`);
          console.log(`  TORUS: ${torus.toFixed(6)}`);
          console.log(`  TitanX: ${titanX.toFixed(2)} (${(titanX / 1e6).toFixed(2)}M)`);
          console.log(`  Tick range: ${burn.args.tickLower} to ${burn.args.tickUpper}`);
          
          // Get the transaction to see more details
          const tx = await provider.getTransaction(burn.transactionHash);
          console.log(`  From address: ${tx.from}`);
        }
      }
    } catch (err) {
      // Skip errors, continue searching
    }
  }
  
  // Also check for DecreaseLiquidity events on known positions
  console.log('\n\nChecking DecreaseLiquidity events for position 1029236...');
  
  try {
    // Search in smaller chunks
    const decreaseFilter = positionManager.filters.DecreaseLiquidity('1029236');
    
    for (let i = 0; i < 10; i++) {
      const fromBlock = currentBlock - (i + 1) * 1000;
      const toBlock = currentBlock - i * 1000;
      
      try {
        const events = await positionManager.queryFilter(decreaseFilter, fromBlock, toBlock);
        
        for (const event of events) {
          console.log(`\nFound DecreaseLiquidity at block ${event.blockNumber}:`);
          console.log(`  Liquidity decreased: ${event.args.liquidity.toString()}`);
          console.log(`  amount0: ${Number(event.args.amount0) / 1e18} TORUS`);
          console.log(`  amount1: ${Number(event.args.amount1) / 1e18} TitanX`);
          
          if (Number(event.args.amount1) / 1e18 > 1000000) {
            console.log(`  🎯 Large TitanX amount!`);
          }
        }
      } catch (err) {
        // Continue
      }
    }
  } catch (err) {
    console.log('Error checking decrease events:', err.message);
  }
}

checkBurnAndCollect().catch(console.error);
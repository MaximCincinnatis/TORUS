const { ethers } = require('ethers');

const provider = new ethers.JsonRpcProvider('https://eth.llamarpc.com');
const NFT_POSITION_MANAGER = '0xC36442b4a4522E871399CD717aBDD847Ab11FE88';

const POSITION_MANAGER_ABI = [
  'function positions(uint256 tokenId) view returns (uint96 nonce, address operator, address token0, address token1, uint24 fee, int24 tickLower, int24 tickUpper, uint128 liquidity, uint256 feeGrowthInside0LastX128, uint256 feeGrowthInside1LastX128, uint128 tokensOwed0, uint128 tokensOwed1)',
  'function ownerOf(uint256 tokenId) view returns (address)',
  'event DecreaseLiquidity(uint256 indexed tokenId, uint128 liquidity, uint256 amount0, uint256 amount1)',
  'event Collect(uint256 indexed tokenId, address recipient, uint256 amount0, uint256 amount1)'
];

async function checkPosition1029236() {
  const positionManager = new ethers.Contract(NFT_POSITION_MANAGER, POSITION_MANAGER_ABI, provider);
  
  console.log('Checking position 1029236 in detail...\n');
  
  const position = await positionManager.positions('1029236');
  const owner = await positionManager.ownerOf('1029236');
  
  console.log(`Owner: ${owner}`);
  console.log(`Token0: ${position.token0}`);
  console.log(`Token1: ${position.token1}`);
  console.log(`Liquidity: ${position.liquidity.toString()}`);
  console.log(`tokensOwed0: ${position.tokensOwed0.toString()}`);
  console.log(`tokensOwed1: ${position.tokensOwed1.toString()}`);
  console.log(`feeGrowthInside0Last: ${position.feeGrowthInside0LastX128.toString()}`);
  console.log(`feeGrowthInside1Last: ${position.feeGrowthInside1LastX128.toString()}`);
  
  // Convert to human readable
  const torus = Number(position.tokensOwed0) / 1e18;
  const titanx = Number(position.tokensOwed1) / 1e18;
  
  console.log(`\nClaimable TORUS: ${torus.toFixed(6)}`);
  console.log(`Claimable TitanX: ${titanx.toFixed(2)} (${(titanx / 1e6).toFixed(2)}M)`);
  
  // Check if this matches the 39M TitanX
  if (titanx > 38000000 && titanx < 40000000) {
    console.log('\n🎯 THIS IS THE POSITION WITH 39M TitanX!');
  }
  
  // Check DecreaseLiquidity events
  console.log('\nChecking DecreaseLiquidity events...');
  const currentBlock = await provider.getBlockNumber();
  const decreaseFilter = positionManager.filters.DecreaseLiquidity('1029236');
  
  try {
    const events = await positionManager.queryFilter(decreaseFilter, currentBlock - 50000, currentBlock);
    console.log(`Found ${events.length} DecreaseLiquidity events`);
    
    for (const event of events) {
      console.log(`  Block ${event.blockNumber}: Decreased ${event.args.liquidity.toString()} liquidity`);
      console.log(`    Got back: ${Number(event.args.amount0)/1e18} TORUS, ${Number(event.args.amount1)/1e18} TitanX`);
    }
  } catch (err) {
    console.log('Error fetching events:', err.message);
  }
  
  // Check Collect events
  console.log('\nChecking Collect events...');
  const collectFilter = positionManager.filters.Collect('1029236');
  
  try {
    const events = await positionManager.queryFilter(collectFilter, currentBlock - 50000, currentBlock);
    console.log(`Found ${events.length} Collect events`);
    
    for (const event of events) {
      console.log(`  Block ${event.blockNumber}: Collected`);
      console.log(`    ${Number(event.args.amount0)/1e18} TORUS`);
      console.log(`    ${Number(event.args.amount1)/1e18} TitanX`);
    }
  } catch (err) {
    console.log('Error fetching collect events:', err.message);
  }
}

checkPosition1029236().catch(console.error);
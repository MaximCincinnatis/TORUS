const { ethers } = require('ethers');

const NFT_POSITION_MANAGER = '0xC36442b4a4522E871399CD717aBDD847Ab11FE88';
const provider = new ethers.JsonRpcProvider('https://ethereum-rpc.publicnode.com');

const POSITION_MANAGER_ABI = [
  'function positions(uint256 tokenId) view returns (uint96 nonce, address operator, address token0, address token1, uint24 fee, int24 tickLower, int24 tickUpper, uint128 liquidity, uint256 feeGrowthInside0LastX128, uint256 feeGrowthInside1LastX128, uint128 tokensOwed0, uint128 tokensOwed1)',
  'function ownerOf(uint256 tokenId) view returns (address)',
  'event Transfer(address indexed from, address indexed to, uint256 indexed tokenId)',
  'event IncreaseLiquidity(uint256 indexed tokenId, uint128 liquidity, uint256 amount0, uint256 amount1)'
];

async function testNFTApproach() {
  console.log('=== TESTING NFT APPROACH FOR LP POSITIONS ===');
  
  try {
    const positionManager = new ethers.Contract(NFT_POSITION_MANAGER, POSITION_MANAGER_ABI, provider);
    const currentBlock = await provider.getBlockNumber();
    const fromBlock = currentBlock - 10000; // ~1.5 days
    
    console.log(`Fetching NFT events from block ${fromBlock} to ${currentBlock}`);
    
    // Get Transfer events (NFT mints)
    const transferFilter = positionManager.filters.Transfer(ethers.ZeroAddress, null, null);
    const transferEvents = await positionManager.queryFilter(transferFilter, fromBlock, currentBlock);
    console.log(`Found ${transferEvents.length} NFT mint events`);
    
    // Get IncreaseLiquidity events
    const increaseLiquidityFilter = positionManager.filters.IncreaseLiquidity();
    const increaseLiquidityEvents = await positionManager.queryFilter(increaseLiquidityFilter, fromBlock, currentBlock);
    console.log(`Found ${increaseLiquidityEvents.length} IncreaseLiquidity events`);
    
    // Collect unique token IDs
    const tokenIds = new Set();
    
    transferEvents.forEach(event => {
      tokenIds.add(event.args.tokenId.toString());
    });
    
    increaseLiquidityEvents.forEach(event => {
      tokenIds.add(event.args.tokenId.toString());
    });
    
    console.log(`\nUnique token IDs: ${tokenIds.size}`);
    console.log('Token IDs:', Array.from(tokenIds).slice(0, 5));
    
    // Check first few positions
    console.log('\n=== CHECKING POSITION DETAILS ===');
    let torusPositions = 0;
    
    for (const tokenId of Array.from(tokenIds).slice(0, 10)) {
      try {
        const positionData = await positionManager.positions(tokenId);
        
        console.log(`\nToken ID ${tokenId}:`);
        console.log(`  Token0: ${positionData.token0}`);
        console.log(`  Token1: ${positionData.token1}`);
        console.log(`  Fee: ${positionData.fee}`);
        console.log(`  Liquidity: ${positionData.liquidity.toString()}`);
        console.log(`  Tick Range: ${positionData.tickLower} to ${positionData.tickUpper}`);
        
        // Check if this is TORUS/TitanX pool
        const isTORUS = (
          (positionData.token0.toLowerCase() === '0xb47f575807fc5466285e1277ef8acfbb5c6686e8') || // TORUS
          (positionData.token1.toLowerCase() === '0xb47f575807fc5466285e1277ef8acfbb5c6686e8')    // TORUS
        );
        
        const isTitanX = (
          (positionData.token0.toLowerCase() === '0xf19308f923582a6f7c465e5ce7a9dc1bec6665b1') || // TitanX
          (positionData.token1.toLowerCase() === '0xf19308f923582a6f7c465e5ce7a9dc1bec6665b1')    // TitanX
        );
        
        if (isTORUS && isTitanX && positionData.liquidity > 0) {
          torusPositions++;
          const owner = await positionManager.ownerOf(tokenId);
          console.log(`  ✅ TORUS/TitanX position! Owner: ${owner}`);
        } else {
          console.log(`  ❌ Not TORUS/TitanX pool`);
        }
        
      } catch (error) {
        console.log(`  Error checking token ${tokenId}: ${error.message}`);
      }
    }
    
    console.log(`\n=== SUMMARY ===`);
    console.log(`Total TORUS/TitanX positions found: ${torusPositions}`);
    
  } catch (error) {
    console.error('Error:', error);
  }
}

testNFTApproach();
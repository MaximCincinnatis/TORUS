// Let's check what Etherscan might be seeing differently
// Maybe there's a position we're missing or fees are calculated differently

const { ethers } = require('ethers');

const provider = new ethers.JsonRpcProvider('https://eth.llamarpc.com');

async function checkEtherscanView() {
  console.log('Checking what might be different about Etherscan view...\n');
  
  // The key insight: Etherscan might be showing PENDING fees that need to be collected
  // These would show up when you SIMULATE a collect or burn transaction
  
  // Let's check if there are any other TORUS pool positions we missed
  const POOL_ADDRESS = '0x7ff1f30F6E7EeC2ff3F0D1b60739115BDF88190F';
  const TARGET = '0xCe32E10b205FBf49F3bB7132f7378751Af1832b6';
  
  console.log('TORUS/TitanX Pool:', POOL_ADDRESS);
  console.log('Target address:', TARGET);
  
  // The positions we know about
  console.log('\nKnown positions:');
  console.log('- 1029236: Liquidity 0, tokensOwed 0/0');
  console.log('- 1030051: Active liquidity, tokensOwed 0/0');
  console.log('- 1031465: Active liquidity, tokensOwed 0/0');
  
  console.log('\nPossible explanations for 39M TitanX showing on Etherscan:');
  console.log('1. Etherscan calculates PENDING fees (not yet in tokensOwed)');
  console.log('2. There is another position we have not found');
  console.log('3. The fees were already collected (between your check and now)');
  console.log('4. Etherscan is showing a different address or pool');
  
  // Let's also check if position 1029236 had liquidity removed but fees not collected
  console.log('\nPosition 1029236 analysis:');
  console.log('- Has feeGrowthInside0LastX128: 443439599953054697926761749378639');
  console.log('- Has feeGrowthInside1LastX128: 7411474927651198285159993665072166865264');
  console.log('- This suggests it PREVIOUSLY earned fees');
  console.log('- But liquidity is 0 and tokensOwed is 0');
  console.log('- This means either:');
  console.log('  a) Fees were already collected');
  console.log('  b) Position was burned without collecting fees first');
  
  // Check block number to see how recent our data is
  const currentBlock = await provider.getBlockNumber();
  console.log(`\nCurrent block: ${currentBlock}`);
  console.log('If Etherscan data is from an earlier block, fees may have been collected since then.');
}

checkEtherscanView().catch(console.error);
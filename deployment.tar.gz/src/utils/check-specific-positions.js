const { ethers } = require('ethers');

const provider = new ethers.JsonRpcProvider('https://eth.llamarpc.com');
const NFT_POSITION_MANAGER = '0xC36442b4a4522E871399CD717aBDD847Ab11FE88';

const POSITION_MANAGER_ABI = [
  'function positions(uint256 tokenId) view returns (uint96 nonce, address operator, address token0, address token1, uint24 fee, int24 tickLower, int24 tickUpper, uint128 liquidity, uint256 feeGrowthInside0LastX128, uint256 feeGrowthInside1LastX128, uint128 tokensOwed0, uint128 tokensOwed1)',
  'function ownerOf(uint256 tokenId) view returns (address)'
];

async function checkPosition(tokenId) {
  const positionManager = new ethers.Contract(NFT_POSITION_MANAGER, POSITION_MANAGER_ABI, provider);
  
  console.log(`\nChecking Token ID: ${tokenId}`);
  try {
    const owner = await positionManager.ownerOf(tokenId);
    const position = await positionManager.positions(tokenId);
    
    console.log(`  Owner: ${owner}`);
    console.log(`  Token0: ${position.token0}`);
    console.log(`  Token1: ${position.token1}`);
    
    // Check if TORUS pool
    const isTorus = position.token0.toLowerCase() === '0xb47f575807fc5466285e1277ef8acfbb5c6686e8' &&
                   position.token1.toLowerCase() === '0xf19308f923582a6f7c465e5ce7a9dc1bec6665b1';
    
    if (isTorus) {
      console.log(`  ✅ TORUS Position!`);
      console.log(`  Liquidity: ${position.liquidity.toString()}`);
      console.log(`  tokensOwed0 (raw): ${position.tokensOwed0.toString()}`);
      console.log(`  tokensOwed1 (raw): ${position.tokensOwed1.toString()}`);
      
      const torus = Number(position.tokensOwed0) / 1e18;
      const titanx = Number(position.tokensOwed1) / 1e18;
      console.log(`  Claimable TORUS: ${torus.toFixed(6)}`);
      console.log(`  Claimable TitanX: ${titanx.toFixed(2)} (${(titanx / 1e6).toFixed(2)}M)`);
      
      // Check if this matches the target
      if (titanx > 38000000 && titanx < 40000000 && torus > 0.7 && torus < 0.8) {
        console.log(`  🎯 FOUND THE POSITION WITH 39M TitanX and 0.76 TORUS!`);
      }
    }
  } catch (err) {
    console.log(`  Error: ${err.message}`);
  }
}

async function main() {
  console.log('Checking various TORUS positions to find the one with 39M TitanX claimable...');
  
  // Check a range of token IDs around the ones we know
  const baseIds = [1030051, 1031465, 1029195];
  
  for (const baseId of baseIds) {
    // Check IDs around each base
    for (let offset = -10; offset <= 10; offset++) {
      await checkPosition(baseId + offset);
    }
  }
  
  // Also check some specific IDs that might be relevant
  const specificIds = [797216, 780889, 798833];
  for (const id of specificIds) {
    await checkPosition(id);
  }
}

main().catch(console.error);
const { ethers } = require('ethers');

const provider = new ethers.JsonRpcProvider('https://eth.llamarpc.com');
const NFT_POSITION_MANAGER = '0xC36442b4a4522E871399CD717aBDD847Ab11FE88';
const POOL_ADDRESS = '0x7ff1f30F6E7EeC2ff3F0D1b60739115BDF88190F';

const POSITION_MANAGER_ABI = [
  'function positions(uint256 tokenId) view returns (uint96 nonce, address operator, address token0, address token1, uint24 fee, int24 tickLower, int24 tickUpper, uint128 liquidity, uint256 feeGrowthInside0LastX128, uint256 feeGrowthInside1LastX128, uint128 tokensOwed0, uint128 tokensOwed1)',
  'function ownerOf(uint256 tokenId) view returns (address)'
];

const POOL_ABI = [
  'function feeGrowthGlobal0X128() view returns (uint256)',
  'function feeGrowthGlobal1X128() view returns (uint256)',
  'function ticks(int24 tick) view returns (uint256 feeGrowthOutside0X128, uint256 feeGrowthOutside1X128, int128 liquidityGross, int128 liquidityNet, uint56 secondsPerLiquidityOutsideX128, uint160 secondsOutside, bool initialized)',
  'function slot0() view returns (uint160 sqrtPriceX96, int24 tick, uint16 observationIndex, uint16 observationCardinality, uint16 observationCardinalityNext, uint8 feeProtocol, bool unlocked)'
];

const Q128 = BigInt(2) ** BigInt(128);

async function calculateRealFees(tokenId) {
  const positionManager = new ethers.Contract(NFT_POSITION_MANAGER, POSITION_MANAGER_ABI, provider);
  const pool = new ethers.Contract(POOL_ADDRESS, POOL_ABI, provider);
  
  console.log(`\n=== Calculating REAL fees for Token ${tokenId} ===`);
  
  const position = await positionManager.positions(tokenId);
  const owner = await positionManager.ownerOf(tokenId);
  
  console.log(`Owner: ${owner}`);
  console.log(`Liquidity: ${position.liquidity.toString()}`);
  console.log(`Tick range: ${position.tickLower} to ${position.tickUpper}`);
  console.log(`Current tokensOwed0: ${position.tokensOwed0.toString()}`);
  console.log(`Current tokensOwed1: ${position.tokensOwed1.toString()}`);
  
  // Get pool state
  const [slot0, feeGrowthGlobal0, feeGrowthGlobal1] = await Promise.all([
    pool.slot0(),
    pool.feeGrowthGlobal0X128(),
    pool.feeGrowthGlobal1X128()
  ]);
  
  const currentTick = Number(slot0.tick);
  console.log(`\nCurrent pool tick: ${currentTick}`);
  
  // Get tick data
  const [tickLowerData, tickUpperData] = await Promise.all([
    pool.ticks(position.tickLower),
    pool.ticks(position.tickUpper)
  ]);
  
  // Calculate fee growth inside
  let feeGrowthBelow0 = BigInt(tickLowerData.feeGrowthOutside0X128);
  let feeGrowthBelow1 = BigInt(tickLowerData.feeGrowthOutside1X128);
  
  if (currentTick < position.tickLower) {
    feeGrowthBelow0 = BigInt(feeGrowthGlobal0) - feeGrowthBelow0;
    feeGrowthBelow1 = BigInt(feeGrowthGlobal1) - feeGrowthBelow1;
  }
  
  let feeGrowthAbove0 = BigInt(tickUpperData.feeGrowthOutside0X128);
  let feeGrowthAbove1 = BigInt(tickUpperData.feeGrowthOutside1X128);
  
  if (currentTick >= position.tickUpper) {
    feeGrowthAbove0 = BigInt(feeGrowthGlobal0) - feeGrowthAbove0;
    feeGrowthAbove1 = BigInt(feeGrowthGlobal1) - feeGrowthAbove1;
  }
  
  const feeGrowthInside0 = BigInt(feeGrowthGlobal0) - feeGrowthBelow0 - feeGrowthAbove0;
  const feeGrowthInside1 = BigInt(feeGrowthGlobal1) - feeGrowthBelow1 - feeGrowthAbove1;
  
  console.log(`\nFee growth calculations:`);
  console.log(`feeGrowthInside0: ${feeGrowthInside0.toString()}`);
  console.log(`feeGrowthInside1: ${feeGrowthInside1.toString()}`);
  console.log(`feeGrowthInside0Last: ${position.feeGrowthInside0LastX128.toString()}`);
  console.log(`feeGrowthInside1Last: ${position.feeGrowthInside1LastX128.toString()}`);
  
  // Calculate uncollected fees
  let totalOwed0 = BigInt(position.tokensOwed0);
  let totalOwed1 = BigInt(position.tokensOwed1);
  
  const liquidity = BigInt(position.liquidity);
  
  if (liquidity > 0) {
    const feeGrowthDelta0 = feeGrowthInside0 - BigInt(position.feeGrowthInside0LastX128);
    const feeGrowthDelta1 = feeGrowthInside1 - BigInt(position.feeGrowthInside1LastX128);
    
    if (feeGrowthDelta0 > 0) {
      const uncollected0 = (liquidity * feeGrowthDelta0) / Q128;
      totalOwed0 += uncollected0;
      console.log(`\nUncollected fees token0: ${uncollected0.toString()}`);
    }
    
    if (feeGrowthDelta1 > 0) {
      const uncollected1 = (liquidity * feeGrowthDelta1) / Q128;
      totalOwed1 += uncollected1;
      console.log(`Uncollected fees token1: ${uncollected1.toString()}`);
    }
  }
  
  const claimableTorus = Number(totalOwed0) / 1e18;
  const claimableTitanX = Number(totalOwed1) / 1e18;
  
  console.log(`\n✅ TOTAL CLAIMABLE:`);
  console.log(`TORUS: ${claimableTorus.toFixed(6)}`);
  console.log(`TitanX: ${claimableTitanX.toFixed(2)} (${(claimableTitanX / 1e6).toFixed(2)}M)`);
  
  return { claimableTorus, claimableTitanX };
}

async function main() {
  console.log('Testing real fee calculation for 0xCe32...32b6 positions...\n');
  
  // Test the known positions
  await calculateRealFees('1030051');
  await calculateRealFees('1031465');
  
  // Also test position 1029236 which had 0 liquidity
  await calculateRealFees('1029236');
}

main().catch(console.error);
const { ethers } = require('ethers');

const provider = new ethers.JsonRpcProvider('https://eth.llamarpc.com');
const NFT_POSITION_MANAGER = '0xC36442b4a4522E871399CD717aBDD847Ab11FE88';
const POOL_ADDRESS = '0x7ff1f30F6E7EeC2ff3F0D1b60739115BDF88190F';

const POSITION_MANAGER_ABI = [
  'function positions(uint256 tokenId) view returns (uint96 nonce, address operator, address token0, address token1, uint24 fee, int24 tickLower, int24 tickUpper, uint128 liquidity, uint256 feeGrowthInside0LastX128, uint256 feeGrowthInside1LastX128, uint128 tokensOwed0, uint128 tokensOwed1)'
];

const POOL_ABI = [
  'function slot0() view returns (uint160 sqrtPriceX96, int24 tick, uint16 observationIndex, uint16 observationCardinality, uint16 observationCardinalityNext, uint8 feeProtocol, bool unlocked)',
  'function feeGrowthGlobal0X128() view returns (uint256)',
  'function feeGrowthGlobal1X128() view returns (uint256)',
  'function ticks(int24 tick) view returns (uint256 feeGrowthOutside0X128, uint256 feeGrowthOutside1X128, int128 liquidityGross, int128 liquidityNet, uint56 secondsPerLiquidityOutsideX128, uint160 secondsOutside, bool initialized)'
];

async function checkInRangePosition() {
  const pool = new ethers.Contract(POOL_ADDRESS, POOL_ABI, provider);
  const positionManager = new ethers.Contract(NFT_POSITION_MANAGER, POSITION_MANAGER_ABI, provider);
  
  console.log('Checking IN-RANGE position 1031465 fees...\n');
  
  const position = await positionManager.positions('1031465');
  const slot0 = await pool.slot0();
  
  const currentTick = Number(slot0.tick);
  const tickLower = Number(position.tickLower);
  const tickUpper = Number(position.tickUpper);
  
  console.log('Position 1031465:');
  console.log(`Owner: 0xCe32E10b205FBf49F3bB7132f7378751Af1832b6`);
  console.log(`Tick range: ${tickLower} to ${tickUpper}`);
  console.log(`Current tick: ${currentTick}`);
  console.log(`In range: ${currentTick >= tickLower && currentTick < tickUpper ? '✓ YES' : 'NO'}`);
  console.log(`Liquidity: ${position.liquidity.toString()}`);
  
  console.log('\nCurrent tokensOwed (already burned in):');
  console.log(`tokensOwed0: ${position.tokensOwed0.toString()}`);
  console.log(`tokensOwed1: ${position.tokensOwed1.toString()}`);
  
  console.log('\nFee growth tracking:');
  console.log(`feeGrowthInside0Last: ${position.feeGrowthInside0LastX128.toString()}`);
  console.log(`feeGrowthInside1Last: ${position.feeGrowthInside1LastX128.toString()}`);
  
  // The fact that feeGrowthInsideLast is 0 means this position hasn't collected fees yet
  // All accumulated fees are still pending
  
  console.log('\n🔑 KEY INSIGHT:');
  console.log('feeGrowthInside0Last = 0 means this position has NEVER collected fees');
  console.log('All fees since position creation are still pending!');
  
  // Get current fee growth
  const [feeGrowthGlobal0, feeGrowthGlobal1] = await Promise.all([
    pool.feeGrowthGlobal0X128(),
    pool.feeGrowthGlobal1X128()
  ]);
  
  console.log('\nCurrent global fee growth:');
  console.log(`feeGrowthGlobal0: ${feeGrowthGlobal0.toString()}`);
  console.log(`feeGrowthGlobal1: ${feeGrowthGlobal1.toString()}`);
  
  // For an in-range position, we need to calculate fee growth inside the range
  // This is complex, but the key is that with feeGrowthInsideLast = 0,
  // ALL the fee growth since position creation is claimable
  
  console.log('\n💡 This explains why Uniswap shows 39M TitanX yield!');
  console.log('The position has been accumulating fees but never collected them.');
  console.log('Our dashboard only shows tokensOwed (0) but not the pending fees.');
}

checkInRangePosition().catch(console.error);
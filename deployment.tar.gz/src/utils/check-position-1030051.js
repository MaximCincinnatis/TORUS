const { ethers } = require('ethers');

const provider = new ethers.JsonRpcProvider('https://eth.llamarpc.com');
const NFT_POSITION_MANAGER = '0xC36442b4a4522E871399CD717aBDD847Ab11FE88';
const POOL_ADDRESS = '0x7ff1f30F6E7EeC2ff3F0D1b60739115BDF88190F';

const POOL_ABI = [
  'function slot0() view returns (uint160 sqrtPriceX96, int24 tick, uint16 observationIndex, uint16 observationCardinality, uint16 observationCardinalityNext, uint8 feeProtocol, bool unlocked)'
];

const POSITION_MANAGER_ABI = [
  'function positions(uint256 tokenId) view returns (uint96 nonce, address operator, address token0, address token1, uint24 fee, int24 tickLower, int24 tickUpper, uint128 liquidity, uint256 feeGrowthInside0LastX128, uint256 feeGrowthInside1LastX128, uint128 tokensOwed0, uint128 tokensOwed1)'
];

async function checkPosition1030051() {
  const pool = new ethers.Contract(POOL_ADDRESS, POOL_ABI, provider);
  const positionManager = new ethers.Contract(NFT_POSITION_MANAGER, POSITION_MANAGER_ABI, provider);
  
  console.log('Checking position 1030051 in detail...\n');
  
  const position = await positionManager.positions('1030051');
  const slot0 = await pool.slot0();
  const currentTick = Number(slot0.tick);
  
  console.log('Position details:');
  console.log(`Liquidity: ${position.liquidity.toString()}`);
  console.log(`Tick range: ${position.tickLower} to ${position.tickUpper}`);
  console.log(`Current pool tick: ${currentTick}`);
  console.log(`In range: ${currentTick >= position.tickLower && currentTick < position.tickUpper ? 'YES' : 'NO'}`);
  
  // Calculate position value
  // This position is OUT OF RANGE (current tick 173375 > upper tick 159000)
  // So all liquidity is in token0 (TORUS)
  
  console.log('\nPosition composition:');
  console.log('Since position is out of range (above), all liquidity is in TORUS');
  
  // The Uniswap interface might be showing accumulated fees differently
  // Let's check what the actual amounts in the position are
  
  const liquidity = Number(position.liquidity) / 1e18;
  console.log(`\nRough liquidity estimate: ${liquidity.toFixed(2)}`);
  
  // Check if this could be the 39M TitanX position
  // Out of range positions accumulate fees in the token they're NOT holding
  // So this TORUS position would accumulate TitanX fees
  
  console.log('\nFee accumulation:');
  console.log('Out-of-range positions above the range accumulate fees in token1 (TitanX)');
  console.log('This could explain why it shows 39M TitanX in fees!');
  
  // The issue might be that we need to calculate fees for out-of-range positions differently
  console.log('\ntokensOwed0:', position.tokensOwed0.toString());
  console.log('tokensOwed1:', position.tokensOwed1.toString());
  
  if (position.tokensOwed0.toString() === '0' && position.tokensOwed1.toString() === '0') {
    console.log('\n⚠️  tokensOwed is 0, but fees might not be burned in yet!');
    console.log('The Uniswap interface calculates these pending fees.');
  }
}

checkPosition1030051().catch(console.error);
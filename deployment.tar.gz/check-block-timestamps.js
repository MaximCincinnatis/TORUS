const { ethers } = require('ethers');

async function checkBlockTimestamps() {
  const provider = new ethers.JsonRpcProvider('https://ethereum-rpc.publicnode.com');
  
  const blocks = [
    21573450,  // Old deployment block
    22890272,  // New deployment block  
    22890437   // First actual Created event
  ];
  
  console.log('Checking block timestamps...\n');
  
  for (const blockNumber of blocks) {
    try {
      const block = await provider.getBlock(blockNumber);
      if (block) {
        const date = new Date(block.timestamp * 1000);
        console.log(`Block ${blockNumber}:`);
        console.log(`  Timestamp: ${block.timestamp}`);
        console.log(`  Date: ${date.toISOString()}`);
        console.log(`  Local: ${date.toLocaleString()}`);
        console.log('');
      } else {
        console.log(`Block ${blockNumber}: NOT FOUND\n`);
      }
    } catch (error) {
      console.error(`Error getting block ${blockNumber}:`, error.message);
    }
  }
}

checkBlockTimestamps().catch(console.error);
const { ethers } = require('ethers');

const RPC_URL = 'https://ethereum-rpc.publicnode.com';
const CONTRACT_ADDRESS = '0xc7cc775b21f9df85e043c7fdd9dac60af0b69507';

const STAKED_EVENT_ABI = {
  "anonymous": false,
  "inputs": [
    {"indexed": true, "internalType": "address", "name": "user", "type": "address"},
    {"indexed": false, "internalType": "uint256", "name": "id", "type": "uint256"},
    {"indexed": false, "internalType": "uint256", "name": "principal", "type": "uint256"},
    {"indexed": false, "internalType": "uint256", "name": "shares", "type": "uint256"},
    {"indexed": false, "internalType": "uint256", "name": "duration", "type": "uint256"},
    {"indexed": false, "internalType": "uint256", "name": "timestamp", "type": "uint256"}
  ],
  "name": "Staked",
  "type": "event"
};

async function testStakeEvents() {
  console.log('Testing Staked events...\n');
  
  const provider = new ethers.JsonRpcProvider(RPC_URL);
  const contract = new ethers.Contract(CONTRACT_ADDRESS, [STAKED_EVENT_ABI], provider);
  
  const currentBlock = await provider.getBlockNumber();
  console.log(`Current block: ${currentBlock}`);
  
  // Search from deployment block
  const deploymentBlock = 21573450;
  console.log(`Contract deployed at block: ${deploymentBlock}`);
  
  // Search in chunks from deployment
  let foundStakes = false;
  let fromBlock = deploymentBlock;
  const chunkSize = 45000;
  
  console.log('\nSearching for Staked events in chunks...');
  
  while (fromBlock < currentBlock && !foundStakes) {
    const toBlock = Math.min(fromBlock + chunkSize, currentBlock);
    
    try {
      process.stdout.write(`\rChecking blocks ${fromBlock} to ${toBlock}...`);
      
      const filter = contract.filters.Staked();
      const events = await contract.queryFilter(filter, fromBlock, toBlock);
      
      if (events.length > 0) {
        foundStakes = true;
        console.log(`\n\n✓ Found ${events.length} Staked events in blocks ${fromBlock}-${toBlock}!`);
        
        console.log('\nFirst 5 events:');
        events.slice(0, 5).forEach((event, idx) => {
          console.log(`\n${idx + 1}. Block ${event.blockNumber}`);
          console.log(`   User: ${event.args.user}`);
          console.log(`   Principal: ${ethers.formatUnits(event.args.principal, 18)} TORUS`);
          console.log(`   Duration: ${event.args.duration} days`);
          console.log(`   Shares: ${event.args.shares}`);
        });
        
        // Get total stake events count
        console.log('\nGetting total count of Staked events...');
        let totalStaked = events.length;
        let searchBlock = toBlock + 1;
        
        while (searchBlock < currentBlock) {
          const endBlock = Math.min(searchBlock + chunkSize, currentBlock);
          const moreEvents = await contract.queryFilter(filter, searchBlock, endBlock);
          totalStaked += moreEvents.length;
          searchBlock = endBlock + 1;
        }
        
        console.log(`\nTotal Staked events from deployment to current: ${totalStaked}`);
      }
      
      fromBlock = toBlock + 1;
    } catch (error) {
      console.error('\nError:', error.message);
      break;
    }
  }
  
  if (!foundStakes) {
    console.log('\n\n⚠️ No Staked events found from deployment to current block!');
  }
}

testStakeEvents();
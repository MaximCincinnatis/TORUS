// Test script to check date alignment logic

const today = new Date();
today.setHours(0, 0, 0, 0);

console.log('Today:', today.toISOString());

// Simulate TitanX calculation
const titanXDates = [];
for (let i = 0; i < 88; i++) {
  const date = new Date(today);
  date.setDate(date.getDate() + i);
  const dateKey = date.toISOString().split('T')[0];
  titanXDates.push(dateKey);
}

// Simulate Shares calculation
const sharesDates = [];
for (let i = 0; i < 88; i++) {
  const date = new Date(today);
  date.setDate(date.getDate() + i);
  const dateKey = date.toISOString().split('T')[0];
  sharesDates.push(dateKey);
}

console.log('\nFirst 5 TitanX dates:', titanXDates.slice(0, 5));
console.log('First 5 Shares dates:', sharesDates.slice(0, 5));

// Check if they match
console.log('\nDo arrays match?', titanXDates.every((date, i) => date === sharesDates[i]));
console.log('TitanX length:', titanXDates.length);
console.log('Shares length:', sharesDates.length);

// Test with sample create data
const sampleCreate = {
  maturityDate: new Date('2025-07-15'),
  titanAmount: '1000000000000000000',
  shares: '2000000000000000000'
};

console.log('\nSample create:');
console.log('Maturity date ISO:', sampleCreate.maturityDate.toISOString().split('T')[0]);
console.log('TitanX would go to:', sampleCreate.maturityDate.toISOString().split('T')[0]);
console.log('Shares would go to:', sampleCreate.maturityDate.toISOString().split('T')[0]);
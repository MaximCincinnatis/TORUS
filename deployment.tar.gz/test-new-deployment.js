const { ethers } = require('ethers');

const RPC_URL = 'https://ethereum-rpc.publicnode.com';
const CONTRACT_ADDRESS = '0xc7cc775b21f9df85e043c7fdd9dac60af0b69507';

// Check both event types
const CREATED_EVENT_ABI = {
  "anonymous": false,
  "inputs": [
    {"indexed": true, "internalType": "address", "name": "user", "type": "address"},
    {"indexed": false, "internalType": "uint256", "name": "stakeIndex", "type": "uint256"},
    {"indexed": false, "internalType": "uint256", "name": "torusAmount", "type": "uint256"},
    {"indexed": false, "internalType": "uint256", "name": "endTime", "type": "uint256"}
  ],
  "name": "Created",
  "type": "event"
};

const STAKED_EVENT_ABI = {
  "anonymous": false,
  "inputs": [
    {"indexed": true, "internalType": "address", "name": "user", "type": "address"},
    {"indexed": false, "internalType": "uint256", "name": "id", "type": "uint256"},
    {"indexed": false, "internalType": "uint256", "name": "principal", "type": "uint256"},
    {"indexed": false, "internalType": "uint256", "name": "shares", "type": "uint256"},
    {"indexed": false, "internalType": "uint256", "name": "duration", "type": "uint256"},
    {"indexed": false, "internalType": "uint256", "name": "timestamp", "type": "uint256"}
  ],
  "name": "Staked",
  "type": "event"
};

async function testBothDeploymentBlocks() {
  console.log('Testing both deployment blocks for events...\n');
  
  const provider = new ethers.JsonRpcProvider(RPC_URL);
  const currentBlock = await provider.getBlockNumber();
  console.log(`Current block: ${currentBlock}`);
  
  const oldDeploymentBlock = 21573450;
  const newDeploymentBlock = 22890272;
  
  console.log(`\n=== Testing OLD deployment block: ${oldDeploymentBlock} ===`);
  
  // Test Created events with old block
  const contractForCreated = new ethers.Contract(CONTRACT_ADDRESS, [CREATED_EVENT_ABI], provider);
  const createdFilter = contractForCreated.filters.Created();
  
  // Check a chunk from old deployment
  let oldCreatedEvents = [];
  try {
    oldCreatedEvents = await contractForCreated.queryFilter(createdFilter, oldDeploymentBlock, oldDeploymentBlock + 50000);
    console.log(`Created events found from old deployment: ${oldCreatedEvents.length}`);
    if (oldCreatedEvents.length > 0) {
      console.log(`First Created event at block: ${oldCreatedEvents[0].blockNumber}`);
    }
  } catch (error) {
    console.error('Error checking old deployment for Created events:', error.message);
  }
  
  // Test Staked events with old block
  const contractForStaked = new ethers.Contract(CONTRACT_ADDRESS, [STAKED_EVENT_ABI], provider);
  const stakedFilter = contractForStaked.filters.Staked();
  
  let oldStakedEvents = [];
  try {
    oldStakedEvents = await contractForStaked.queryFilter(stakedFilter, oldDeploymentBlock, oldDeploymentBlock + 50000);
    console.log(`Staked events found from old deployment: ${oldStakedEvents.length}`);
    if (oldStakedEvents.length > 0) {
      console.log(`First Staked event at block: ${oldStakedEvents[0].blockNumber}`);
    }
  } catch (error) {
    console.error('Error checking old deployment for Staked events:', error.message);
  }
  
  console.log(`\n=== Testing NEW deployment block: ${newDeploymentBlock} ===`);
  
  // Test Created events with new block
  let newCreatedEvents = [];
  try {
    newCreatedEvents = await contractForCreated.queryFilter(createdFilter, newDeploymentBlock, newDeploymentBlock + 50000);
    console.log(`Created events found from new deployment: ${newCreatedEvents.length}`);
    if (newCreatedEvents.length > 0) {
      console.log(`First Created event at block: ${newCreatedEvents[0].blockNumber}`);
      console.log(`  User: ${newCreatedEvents[0].args.user.slice(0, 10)}...`);
      console.log(`  TORUS Amount: ${ethers.formatEther(newCreatedEvents[0].args.torusAmount)}`);
    }
  } catch (error) {
    console.error('Error checking new deployment for Created events:', error.message);
  }
  
  // Test Staked events with new block
  let newStakedEvents = [];
  try {
    newStakedEvents = await contractForStaked.queryFilter(stakedFilter, newDeploymentBlock, newDeploymentBlock + 50000);
    console.log(`Staked events found from new deployment: ${newStakedEvents.length}`);
    if (newStakedEvents.length > 0) {
      console.log(`First Staked event at block: ${newStakedEvents[0].blockNumber}`);
    }
  } catch (error) {
    console.error('Error checking new deployment for Staked events:', error.message);
  }
  
  // Also check recent blocks
  console.log(`\n=== Checking RECENT blocks (last 10,000) ===`);
  const recentFromBlock = currentBlock - 10000;
  
  try {
    const recentCreated = await contractForCreated.queryFilter(createdFilter, recentFromBlock, currentBlock);
    console.log(`Recent Created events (last 10k blocks): ${recentCreated.length}`);
  } catch (error) {
    console.error('Error checking recent Created events:', error.message);
  }
  
  try {
    const recentStaked = await contractForStaked.queryFilter(stakedFilter, recentFromBlock, currentBlock);
    console.log(`Recent Staked events (last 10k blocks): ${recentStaked.length}`);
  } catch (error) {
    console.error('Error checking recent Staked events:', error.message);
  }
  
  // Summary
  console.log(`\n=== SUMMARY ===`);
  if (oldCreatedEvents.length > 0 && newCreatedEvents.length === 0) {
    console.log(`✓ Events start at OLD deployment block: ${oldDeploymentBlock}`);
  } else if (newCreatedEvents.length > 0 && oldCreatedEvents.length === 0) {
    console.log(`✓ Events start at NEW deployment block: ${newDeploymentBlock}`);
  } else if (oldCreatedEvents.length > 0 && newCreatedEvents.length > 0) {
    console.log(`⚠️  Events found at BOTH deployment blocks - needs investigation`);
  } else {
    console.log(`⚠️  No events found at either deployment block`);
  }
}

testBothDeploymentBlocks().catch(console.error);